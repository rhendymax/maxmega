{
    "name" : "OpenERP Web mobile",
    "category": "Hidden",
    "description":
        """
        OpenERP Web mobile.
        """,
    "version" : "2.0",
    "depends" : [],
    'active': True,
}
