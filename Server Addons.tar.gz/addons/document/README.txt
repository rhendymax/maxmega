To be done:
-----------

* Test to not create several times the same file / directory
  -> May be put a sql_constraints uniq on several files
  -> test through remove or put

* Retest everything
