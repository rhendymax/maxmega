# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

{
    'name': 'Retro-Planning on Events',
    'version': '0.1',
    'category': 'Tools',
    'complexity': "easy",
    'description': """
Organization and management of events.
======================================

This module allows you to create retro planning for managing your events.
""",
    'author': 'OpenERP SA',
    'images': ['images/event.jpeg'],
    'depends': ['project_retro_planning', 'event'],
    'init_xml': [],
    'update_xml': ['wizard/event_project_retro_view.xml', 'event_project_view.xml'],
    'demo_xml': [],
    'installable': True,
    'auto_install': False,
    'certificate': '0069726863885',
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
