from pdf import PdfFileReader, PdfFileWriter
#.apidoc title: pyPdf Engine

__all__ = ["pdf"]


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
