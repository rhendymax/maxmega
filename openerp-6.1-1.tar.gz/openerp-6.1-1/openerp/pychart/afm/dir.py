# -*- coding: utf-8 -*-
afm = {}

