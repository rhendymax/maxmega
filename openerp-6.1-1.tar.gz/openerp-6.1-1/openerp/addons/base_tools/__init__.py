# Debian packaging removes blank files, so this comment is added.

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
