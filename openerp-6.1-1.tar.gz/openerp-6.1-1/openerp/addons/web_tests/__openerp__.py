{
    "name": "Tests",
    "category": "Hidden",
    "description":
        """
        OpenERP Web test suite.
        """,
    "version": "2.0",
    "depends": [],
    "js": ["static/src/js/*.js"],
    "css": ['static/src/css/*.css'],
    'active': True,
}
